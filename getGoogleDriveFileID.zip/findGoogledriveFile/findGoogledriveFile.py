import pickle
import os
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from tabulate import tabulate
import configReader
import exceptionHandler

sourceFile = ''
output = ''

try:
    configParams = configReader.getParameters()
    sourceFile = configParams["Source Filename"]
    extractedDataFolder = configParams["Extracted Data Folder"]
    print(sourceFile)
    # open output file
    output = open(extractedDataFolder + "\\" + "File_Details.txt", "w")

    # If modifying these scopes, delete the file token.pickle.
    SCOPES = ['https://www.googleapis.com/auth/drive.metadata.readonly']

    def get_gdrive_service():
        creds = None
        # The file token.pickle stores the user's access and refresh tokens, and is
        # created automatically when the authorization flow completes for the first
        # time.
        if os.path.exists('token.pickle'):
            with open('token.pickle', 'rb') as token:
                creds = pickle.load(token)
        # If there are no (valid) credentials available, let the user log in.
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_secrets_file(
                    'credentials.json', SCOPES)
                creds = flow.run_local_server(port=0)
            # Save the credentials for the next run
            with open('token.pickle', 'wb') as token:
                pickle.dump(creds, token)
        # return Google Drive API service
        return build('drive', 'v3', credentials=creds)


    def main():
        """Shows basic usage of the Drive v3 API.
        Prints the names and ids of the first 5 files the user has access to.
        """
        service = get_gdrive_service()
        # Call the Drive v3 API
        results = service.files().list(
            pageSize=1000, fields="nextPageToken, files(id, name)").execute()
        # get the results
        items = results.get('files', [])
        # list all 20 files & folders
        list_files(items, sourceFile)


    def list_files(items, sourcefile):
        """given items returned by Google Drive API, prints them in a tabular way"""
        if not items:
            # empty drive
            print('No files found in drive.')
        else:
            rows = []
            for item in items:
                print(item["name"])
                if item["name"].upper().strip() == sourcefile.upper().strip():
                    # get the File ID
                    id = item["id"]
                    # get the name of file
                    name = item["name"]
                    # append everything to the list
                    rows.append((id, name))
                    output.write(id)

            print("Files:")
            # convert to a human-readable table
            table = tabulate(rows, headers=["ID", "Name"])
            # print the table
            print(table)


    if __name__ == '__main__':
        main()

except Exception as inst:
    exceptionHandler.exceptionHandler(sourceFile, "Source Filename", inst)
finally:
    output.close()
