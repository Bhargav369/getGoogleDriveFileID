# read config parameters
import re

def getParameters():
 configParams = {
    "Deal Source Filename": "",
	"Invoice Source Filename": "",
    "Extracted Data Folder": "ExtractedData",
    "Exception Folder": "alerts",
    "Exception File": "ErrorLog.txt",
    "Log Folder": "logs",
    "Log Filename":"ExtractionLog.txt"
 }
    
    
 # Load the configuration file
 configData = open("config.txt", "r")
 for line in configData:
    pattern = '([A-Z|a-z|\d| ]+[a-z]) *: *([-|\d|A-Z|_|a-z| |.]+)'
    x = re.findall(pattern, line)
    if len(x) != 0:
        key = x[0][0]
        value = x[0][1]
        configParams[key] = value
        
 configData.close()
 return(configParams)
