#version 1: exception handler
import datetime
import configReader

configParams = configReader.getParameters()
exceptionFolder = configParams["Exception Folder"]
exceptionFile = configParams["Exception File"]
logFolder = configParams["Log Folder"]
logFilename = configParams["Log Filename"]

def exceptionHandler(sourceFile, table_name, inst):
    
    log = open(logFolder + '\\' + logFilename, "a")
    errorLog = open(exceptionFolder + "\\" + exceptionFile, "a")

    log.write("************************** \n")
    timestamp = datetime.datetime.now()
    log.write(timestamp.strftime("%c"))
    log.write(": ")
    log.write("Exception in: " + sourceFile + "; while extracting table: " + table_name + "\n")
    
    log.write(str(type(inst)))    # the exception instance
    log.write(str(inst.args))     # arguments stored in .args
    log.write(str(inst))
    log.write("\n")
    
    errorLog.write("************************** \n")
    errorLog.write(timestamp.strftime("%c"))
    errorLog.write(": ")
    errorLog.write("Exception in: " + sourceFile + "; while extracting table: " + table_name + "\n")

    errorLog.write(str(type(inst)))    # the exception instance
    errorLog.write(str(inst.args))     # arguments stored in .args
    errorLog.write(str(inst))
    errorLog.write("\n")
    
    log.close()
    errorLog.close()

# end of definition: exception handler



